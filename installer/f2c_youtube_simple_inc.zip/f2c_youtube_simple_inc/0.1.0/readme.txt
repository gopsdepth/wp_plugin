=== Simple youtube search include by gopsdepth ===
Contributors: gopsdepth
Donate link: http://satjapotport.co.nf/
Tags: youtube,post
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple youtube search include plug-in is a short-code plug-in that will help you add youtube video with search terms.

== Description ==

= Overview =
Simple youtube search include plug-in is a short-code plug-in that will help you add youtube video with search terms. 

= How to use =
Simple to use, you just add this short-code
`[f2c_youtube_inc s="search terms"]`
*** "s" attribute is required attribute.*

= How it works =
The plug-in will get your search terms form "s" attribute and send them to youtube search page then it retrieves first video link in search list. After it get the link, it will create a wordpress youtube short-code so you can use wordpress youtube short-code attributes such as width, height, etc.

== Installation ==

1. Connect to WordPress Admin Panel
2. Click the "Plugins" menu on the left and choose "Add New". Search for “Simple youtube search include by gopsdepth” and install it.
3. Activate the plugin through the 'Plugins' menu in WordPress 
4. Place `[f2c_youtube_inc s="search terms"]` to any posts you want.

== Frequently asked questions ==

= A question that someone might have =

Now, no question.

== Screenshots ==

1. Place short-code following a screen shot.
2. Youtube video will automatically show without indicating a url.

== Changelog ==

None.

== Upgrade notice ==

None.
