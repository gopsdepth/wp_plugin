/*
 * Javascript file
 */
(function($) {
	$(function() {
		$('#f2c_cac_form').validate();
	});
})(jQuery);